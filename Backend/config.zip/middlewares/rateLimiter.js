const redisClient = require("../config/redisClient");
const moment = require('moment');

const rateLimiter = async (req, res, next) => {
  const bucketKey = 'token_bucket';

  const capacity = 10;

  const interval = 1;

  const currentTime = moment().unix();

  const exists = await redisClient.exists(bucketKey);

  if (!exists) {
    await redisClient.hSet(bucketKey, {
      capacity: capacity,
      tokens: capacity,
      lastRefillTime: currentTime,
    });
  }

  const bucketInfo = await redisClient.hGetAll(bucketKey);

  const elapsedTime = currentTime - parseInt(bucketInfo.lastRefillTime);

  const tokensToAdd = Math.floor(elapsedTime / interval);

  const newTokens = Math.min(capacity, parseInt(bucketInfo.tokens) + tokensToAdd);

  await redisClient.hSet(bucketKey, {
    tokens: newTokens,
    lastRefillTime: currentTime,
  });

  if (parseInt(bucketInfo.tokens) > 0) {
    await redisClient.hSet(bucketKey, 'tokens', parseInt(bucketInfo.tokens) - 1);
    next();
  } else {
    res.status(429).json({
      success: false,
      message: 'Rate limit exceeded. Try again later.',
    });
  }
};

module.exports = rateLimiter;

exports.getData = (req, res) => {
    res.json({ message: "Request successful", data: "Your data goes here" });
  };
  